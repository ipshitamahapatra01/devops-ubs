package MavenSpringCore.MavenSpringCoreComponent;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mycompany.springcore.annotations.componentscan.BankAccount;
import com.mycompany.springcore.annotations.componentscan.Customer;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
    	Customer customer = (Customer)context.getBean("customer");
    	customer.showCustomerDetails();
    	
    	BankAccount account = (BankAccount)context.getBean("bankAccount");
    	System.out.println(account.getAcntNo()+" : "+account.getBalance());
    }
}
