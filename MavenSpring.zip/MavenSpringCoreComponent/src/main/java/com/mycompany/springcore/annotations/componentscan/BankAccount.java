package com.mycompany.springcore.annotations.componentscan;

import org.springframework.stereotype.Component;

@Component
public class BankAccount {
	
	private int acntNo;
	private float balance;
	
	public int getAcntNo() {
		return acntNo;
	}
	public void setAcntNo(int acntNo) {
		this.acntNo = acntNo;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	
	

}
