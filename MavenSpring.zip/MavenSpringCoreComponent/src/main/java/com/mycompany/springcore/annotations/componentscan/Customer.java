package com.mycompany.springcore.annotations.componentscan;

import org.springframework.stereotype.Component;

@Component
public class Customer {
	
	public void showCustomerDetails() {
		System.out.println("Name: Ipshita");
		System.out.println("City: Pune");
	}
	

}
