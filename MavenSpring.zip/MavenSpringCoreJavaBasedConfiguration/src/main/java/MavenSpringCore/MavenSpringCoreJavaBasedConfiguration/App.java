package MavenSpringCore.MavenSpringCoreJavaBasedConfiguration;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext; 

import com.mycompany.springcore.config.HelloWorldConfig;
import com.mycompany.springcore.pojo.HelloWorld;

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext ctx = new AnnotationConfigApplicationContext(HelloWorldConfig.class);
    	HelloWorld helloWorld = ctx.getBean (HelloWorld.class);
    	
    	helloWorld.setWish("Hi Ipshita");
    	System.out.println(helloWorld.getWish());   	
    }
}
