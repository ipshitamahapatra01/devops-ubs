package com.mycompany.springcore.pojo;

public class HelloWorld {
	String wish;

	public String getWish() {
		return wish;
	}

	public void setWish(String wish) {
		this.wish = wish;
	}
	
}
