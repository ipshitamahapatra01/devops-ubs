package com.mycompany.springcore.setterinjection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mycompany.springcore.setterinjection.Employee;

public class MainEmployee {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		Employee emp = (Employee)context.getBean("emp");
		
		System.out.println(emp.getId());
		System.out.println(emp.getName());
		System.out.println(emp.getAddress().getFlatNo());
		System.out.println(emp.getAddress().getApartmentName());
		System.out.println(emp.getAddress().getArea());
		System.out.println(emp.getAddress().getCity());
	}

}
