package com.mycompany.springcore.qualifier.pojo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Payment {
	
	@Autowired
	@Qualifier("oracleOrder")
	private Order order;
	
	@Override
	public String toString() {
		return "ordering "+this.order.getItem()+" | price: "+this.order.getPrice();
	}

}
