package com.mycompany.springcore.qualifier.pojo;

public class Order {
	
	private String Item;
	private String Price;
	public String getItem() {
		return Item;
	}
	public void setItem(String item) {
		Item = item;
	}
	public String getPrice() {
		return Price;
	}
	public void setPrice(String price) {
		Price = price;
	}
	

}
