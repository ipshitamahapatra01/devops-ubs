package MavenSpringCore.MavenSpringCoreQualifier;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mycompany.springcore.qualifier.pojo.Payment;


public class App  {
    public static void main( String[] args ) {
    	ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
    	
    	Payment paymentGateway = (Payment)context.getBean("payment");
    	System.out.println(paymentGateway.toString());
    	
    	
    }
}
                                           