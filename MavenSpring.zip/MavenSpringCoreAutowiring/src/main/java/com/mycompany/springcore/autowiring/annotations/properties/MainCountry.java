package com.mycompany.springcore.autowiring.annotations.properties;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mycompany.springcore.autowiring.annotations.properties.Capital;
import com.mycompany.springcore.autowiring.annotations.properties.Country;


public class MainCountry {
    public static void main( String[] args ) {
    	ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
    	
    	Country countryObj = (Country)context.getBean("countryBean");
    	System.out.println(countryObj.getCountryName());
    	
    	Capital capital=countryObj.getCapital();
    	System.out.println(capital.getCapitalName()+" is the capital of "+countryObj.getCountryName());
    	
    }
}
