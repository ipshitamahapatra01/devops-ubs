package com.mycompany.springcore.autowiring.annotations.properties;

public class Capital {
	
	String capitalName;

	public String getCapitalName() {
		return capitalName;
	}

	public void setCapitalName(String capitalName) {
		this.capitalName = capitalName;
	}
	
}
