package com.mycompany.springcore.autowiring.annotation.setters;

import org.springframework.beans.factory.annotation.Autowired;

public class Country {
	
	String countryName;
	
	Capital capital;

	
//	public Country(Capital capital) {
//		super();
//		//this.countryName = countryName;
//		this.capital = capital;
//	}

	public String getCountryName() {
		return countryName;
	}

	@Autowired
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public Capital getCapital() {
		return capital;
	}
	@Autowired
	public void setCapital(Capital capital) {
		this.capital = capital;
	}
	
	
}
