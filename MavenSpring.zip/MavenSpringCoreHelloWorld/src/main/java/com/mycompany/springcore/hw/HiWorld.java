package com.mycompany.springcore.hw;

public class HiWorld {
	
	String wish;

	public String getWish() {
		return wish;
	}

	public void setWish(String wish) {
		this.wish = wish;
	}
	

}
