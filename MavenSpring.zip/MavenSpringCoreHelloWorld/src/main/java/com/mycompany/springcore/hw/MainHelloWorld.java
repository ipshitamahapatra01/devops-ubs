package com.mycompany.springcore.hw;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainHelloWorld {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		
		//Dependency injection
		HelloWorld helloWorld = (HelloWorld)context.getBean("helloWorld");
		
		System.out.println(helloWorld.getWish());
		
		HiWorld hiWorld = (HiWorld)context.getBean("hiWorld");
		
		System.out.println(hiWorld.getWish());
	
		Employee employee = (Employee)context.getBean("employee");
		
		System.out.println(employee.getId());
		System.out.println(employee.getName());
		System.out.println(employee.getAddress());
		
	}

}
