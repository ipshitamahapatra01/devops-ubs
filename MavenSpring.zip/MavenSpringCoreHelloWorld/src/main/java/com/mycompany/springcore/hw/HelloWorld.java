package com.mycompany.springcore.hw;

public class HelloWorld {
	
	String wish,wish2;

	public String getWish2() {
		return wish2;
	}

	public void setWish2(String wish2) {
		this.wish2 = wish2;
	}

	public String getWish() {
		return wish;
	}

	public void setWish(String wish) {
		this.wish = wish;
	}

}
